plotBase <- function (x) 
{
    plotPoints <- as.numeric(x[["assays"]][1, ])
    plotTitle <- sprintf("Feature %s (ID: %s)", x[["features"]][1, 
        "featureVar01"], x[["features"]][1, "customID"])
    plotLabels <- x[["samples"]][["sampleVar01"]]
    par(cex.main = 2)
    plot(x = plotPoints, main = plotTitle, xlab = "Samples", 
        ylab = "Expression level")
    text(x = plotPoints, labels = plotLabels, pos = 4)
}
plotMultiFeature <- function (x) 
{
    if (nrow(x[["assays"]]) < 2) {
        stop("This plotting function requires at least 2 features")
    }
    pca <- prcomp(t(x[["assays"]]), scale. = TRUE)$x
    plot(pca[, 1], pca[, 2], col = as.factor(x$samples$sampleVar01), 
        xlab = "PC 1", ylab = "PC 2", main = "PCA")
}
plotMultiTestSf <- function (x) 
{
    var_x <- data.frame(lapply(x$results, `[`, 2))
    colnames(var_x) <- names(x$results)
    var_x <- data.table(features = rownames(var_x), var_x)
    var_x <- melt(var_x, measure.vars = c(2, 3))
    var_y <- data.frame(lapply(x$results, `[`, 3))
    colnames(var_y) <- names(x$results)
    var_y <- data.table(features = rownames(var_y), var_y)
    var_y <- melt(var_y, measure.vars = c(2, 3))
    df <- merge(var_x, var_y, by = c("variable", "features"))
    plot(df$value.x ~ df$value.y, col = factor(df$variable))
}
plotMultiTestMf <- function (x) 
{
    var_x <- data.frame(lapply(x$results, `[`, 2))
    colnames(var_x) <- names(x$results)
    var_x <- data.table(features = rownames(var_x), var_x)
    var_x <- melt(var_x, measure.vars = c(2, 3))
    var_y <- data.frame(lapply(x$results, `[`, 3))
    colnames(var_y) <- names(x$results)
    var_y <- data.table(features = rownames(var_y), var_y)
    var_y <- melt(var_y, measure.vars = c(2, 3))
    df <- merge(var_x, var_y, by = c("variable", "features"))
    plot(df$value.x ~ df$value.y, col = factor(df$variable))
}
multiModel_scatterplot <- function (x) 
{
    ggdf <- data.frame(var1 = x[[1]]$results[[1]][, "beta"], 
        var2 = x[[2]]$results[[1]][, "beta"])
    plot(x = ggdf$var1, y = ggdf$var2)
}
multiModel_barplot_sf <- function (x) 
{
    df <- data.frame(name = names(x)[1:length(x) - 1], beta = c(x[[1]]$results[[1]][, 
        "beta"], x[[2]]$results[[1]][, "beta"]))
    barplot(height = df$beta, names = df$name, xlab = x[[1]]$results[[1]]$features_id, 
        ylim = c(ifelse(min(df$beta) < 0, min(df$beta) * 1.5, 
            -min(df$beta) * 1.5), max(df$beta) * 1.5))
}
plotGg <- function (x) 
{
    plotPoints <- as.numeric(x[["assays"]][1, ])
    featureMedian <- median(plotPoints)
    plotTitle <- sprintf("%s, median: %0.2f", x[["features"]][["customID"]], 
        featureMedian)
    d <- data.frame(i = seq_along(plotPoints), plotPoints)
    ggplot2::ggplot(d, ggplot2::aes(x = .data$i, y = .data$plotPoints)) + 
        ggplot2::geom_point() + ggplot2::labs(x = "Samples", 
        y = "Expression level", title = plotTitle)
}
plotPlotly <- function (x) 
{
    plotPoints <- as.numeric(x[["assays"]][1, ])
    featureMedian <- median(plotPoints)
    plotTitle <- sprintf("%s, median: %0.2f", x[["features"]][["customID"]], 
        featureMedian)
    d <- data.frame(i = seq_along(plotPoints), plotPoints)
    p <- ggplot2::ggplot(d, ggplot2::aes(x = .data$i, y = .data$plotPoints)) + 
        ggplot2::geom_point() + ggplot2::labs(x = "Samples", 
        y = "Expression level", title = plotTitle)
    plotly::ggplotly(p)
}
